from flask import Flask, request, redirect, render_template
import os
app = Flask(__name__)
app.template_folder = 'src'

METRICS_DATA = """You don't need this page"""


@app.route('/')
def index():
    return redirect('/health_monitor')

@app.route('/admin')
def admin():
    return redirect('/debug')

@app.route('/health_monitor')
def health_monitor():
    return render_template('index.html')


@app.route('/metrics')
def metrics():
    return METRICS_DATA


@app.route('/debug')
def debug():
    return "[DEBUG MODE] Current internal routes: /metrics, /internal/admin/flag"


@app.route('/internal/admin/flag')
def get_flag():
    # if request.remote_addr not in ['127.0.0.1', '::1','172.18.0.2']:
    #     return "Access denied: External network\n"+request.remote_addr, 403
    return os.getenv("FLAG")


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=7000)
