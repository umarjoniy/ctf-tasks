from flask import Flask, request, render_template, redirect, render_template_string
import requests
from urllib.parse import urlparse
import re

app = Flask(__name__)
app.secret_key = 'sup3r_s3cr3t_k3y_CT_F_123'  # Insecure for demo purposes
app.template_folder='src'


@app.route('/')
def index():
    return redirect('/health_monitor')

@app.route('/admin', methods=["GET"])
def admin():
    if request.remote_addr in ['127.0.0.1','::1']:
        return "This page was moved to the domain 'internal_admin'. Contact the admin to get full address", 301
    return "Access denied: External network", 403


@app.route('/health_monitor')
def health_monitor():
    return render_template('index.html')


@app.route('/check_status', methods=['POST'])
def check_status():
    endpoint = request.form.get('endpoint', '')
    if not endpoint:
        return "Endpoint required", 400

    try:
        if not re.match(r'^https?://', endpoint):
            return "Invalid protocol", 400

        response = requests.get(
            endpoint,
            headers={'User-Agent': 'InternalDashboard/1.0'},
            timeout=3
        )
        return render_template('index.html',
                               result=f"Status Code: {response.status_code}\n\n{response.text}",
                               logged_in=True)

    except Exception as e:
        return render_template('index.html',
                               result=f"Error checking endpoint: {str(e)}",
                               logged_in=True)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)