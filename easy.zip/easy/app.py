from flask import Flask, render_template, request, jsonify
import subprocess
import logging
import re
import requests

app = Flask(__name__)


@app.after_request
def add_security_headers(response):
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    response.headers['Strict-Transport-Security'] = "max-age=31536000; includeSubDomains"
    response.headers['X-Content-Type-Options'] = "nosniff"
    response.headers['X-Frame-Options'] = "SAMEORIGIN"
    response.headers['X-XSS-Protection'] = "1; mode=block"
    return response


logging.basicConfig(level=logging.INFO)


def is_valid_domain(domain: str) -> bool:
    """
    Validates if the input is a domain name (strictly, not an IP address).
    """
    domain_regex = re.compile(
        r"^(?=.{1,253}$)"  # total length up to 253
        r"(?!\-)([a-zA-Z0-9\-]{1,63}(?<!\-)\.)+"  # labels (up to 63 chars), no starting/ending dash
        r"[a-zA-Z]{2,63}$"  # TLD
    )

    ip_regex = re.compile(
        r"^(?:\d{1,3}\.){3}\d{1,3}$"  # IPv4
        r"|^\[?[a-fA-F0-9:]+\]?$"  # IPv6 (basic)
    )

    # Must match domain regex and must NOT match IP regex
    return bool(domain_regex.match(domain)) and not ip_regex.match(domain)


@app.route('/', methods=['GET'])
def index():
    if request.remote_addr in ['127.0.0.1', '::1']:
        return "c7_flag{tr7cks_f0r_g33ks}", 200
    return render_template('index.html')


import socket


def get_ip_from_domain(domain: str) -> str:
    try:
        ip_address = socket.gethostbyname(domain)
        return ip_address
    except socket.gaierror as e:
        raise ValueError(f"Could not resolve domain '{domain}': {e}")


@app.route('/ssrf', methods=['GET'])
def diagnose():
    domain = request.args.get('domain')
    if not domain:
        return jsonify({"error": "No nomain provided"}), 400

    if not is_valid_domain(domain):
        return "Please, provide a correct domain", 200

    ip = get_ip_from_domain(domain)
    if ip in ['127.0.0.1','::1']:
        return "c7_flag{tr7cks_f0r_g33ks}", 200
    return "Nope"


if __name__ == '__main__':
    app.run('0.0.0.0', debug=False)
