from flask import Flask, render_template, request, jsonify
import subprocess
import logging
import re

app = Flask(__name__)

@app.after_request
def add_security_headers(response):
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    response.headers['Strict-Transport-Security'] = "max-age=31536000; includeSubDomains"
    response.headers['X-Content-Type-Options'] = "nosniff"
    response.headers['X-Frame-Options'] = "SAMEORIGIN"
    response.headers['X-XSS-Protection'] = "1; mode=block"
    return response

logging.basicConfig(level=logging.INFO)

def sanitize_input(input_str):
    sql_keywords = ["SELECT", "INSERT", "UPDATE", "DELETE"]
    for keyword in sql_keywords:
        if keyword in input_str.upper():
            return False
    return True

def network_util_check_connectivity(ip_address):
    blocked_payloads = re.compile(r'cat|curl|pwd|id|head|tail|less|more|base64|rev|ls', re.IGNORECASE)
    if blocked_payloads.search(ip_address.lower()):
        return "Hacking Attempt!", 400

    # Corrected vulnerable part
    sanitized_ip = ip_address.replace("&", "").replace("|", "").replace(' ','').replace(';','')
    try:
        # Construct command as a single string without shlex.split
        ping_cmd = f"ping -c 1 {sanitized_ip}"
        print(f'{ping_cmd=}')
        # shell=True with a string allows command injection
        output = subprocess.run(ping_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print("Stage1")
        print(f'{output=}')
        if output.returncode != 0:
            print('ReturnCode')
            logging.info(f"Testing IP: {ip_address} failed")
            return "Error while executing a check", 400
        logging.info(f"Testing IP: {ip_address}")
        return f"Command: {ping_cmd}Output: {str(output.stdout)}", 200
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        return "Something went wrong", 500

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/diagnose', methods=['GET'])
def diagnose():
    ip_address = request.args.get('ip_address')
    if not ip_address:
        return jsonify({"error": "Diagnostics failed"}), 400

    if not sanitize_input(ip_address):
        return jsonify({"error": "Diagnostics failed"}), 400

    result, code = network_util_check_connectivity(ip_address)
    return jsonify({"result": result}), code

@app.route('/admin')
def admin():
    return "Admin area. Please keep out."

@app.route('/login', methods=['GET', 'POST'])
def login():
    return jsonify({"error": "Login failed"}), 401

if __name__ == '__main__':
    app.run('0.0.0.0',debug=False)